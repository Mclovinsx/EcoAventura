// Export pages
export '/pages/perfil/loginpage/loginpage_widget.dart' show LoginpageWidget;
export '/pages/perfil/homepage/homepage_widget.dart' show HomepageWidget;
export '/pages/outros/indisponivelpage/indisponivelpage_widget.dart'
    show IndisponivelpageWidget;
export '/pages/minijogos_page/minijogos_page_widget.dart'
    show MinijogosPageWidget;
export '/pages/perfil/missoes_page/missoes_page_widget.dart'
    show MissoesPageWidget;
export '/pages/perfil/c_e_ppage/c_e_ppage_widget.dart' show CEPpageWidget;
export '/pages/games/page_ranking/page_ranking_widget.dart'
    show PageRankingWidget;
export '/pages/importante/informpage/informpage_widget.dart'
    show InformpageWidget;
export '/pages/perfil/perfilpage/perfilpage_widget.dart' show PerfilpageWidget;
export '/pages/naoimplementados/zonapage/zonapage_widget.dart'
    show ZonapageWidget;
export '/pages/perfil/editarperfilpage/editarperfilpage_widget.dart'
    show EditarperfilpageWidget;
export '/pages/perfil/casdastronamepage/casdastronamepage_widget.dart'
    show CasdastronamepageWidget;
export '/pages/importante/duvidaspage/duvidaspage_widget.dart'
    show DuvidaspageWidget;
export '/pages/perfil/pass/pass_widget.dart' show PassWidget;
export '/pages/games/quiztal/quiztal_widget.dart' show QuiztalWidget;
