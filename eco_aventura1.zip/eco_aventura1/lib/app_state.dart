import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/api_requests/api_manager.dart';
import 'backend/supabase/supabase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _login = prefs.getStringList('ff_login') ?? _login;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  List<QuizQuestoesStruct> _quizQuestoes = [
    QuizQuestoesStruct.fromSerializableMap(jsonDecode(
        '{\"questao_texto\":\"O que significa a palavra \\\"reciclar\\\"?\",\"opcoes\":\"[\\\"Jogar tudo no mesmo lixo.\\\",\\\"Transformar materiais usados em coisas novas.\\\",\\\"Usar um produto uma única vez.\\\",\\\"Queimar o lixo.\\\"]\",\"correta_pergunta\":\"1\"}')),
    QuizQuestoesStruct.fromSerializableMap(jsonDecode(
        '{\"questao_texto\":\"Por que é importante cuidar dos rios e lagos?\",\"opcoes\":\"[\\\"Porque eles não servem para nada.\\\",\\\"Porque eles são importantes para os animais e\\\\n para nós.\\\",\\\"Porque eles são feios e sujos.\\\",\\\"Porque podemos jogar lixo neles.\\\"]\",\"correta_pergunta\":\"1\"}')),
    QuizQuestoesStruct.fromSerializableMap(jsonDecode(
        '{\"questao_texto\":\"Por que é importante separar o lixo reciclável do lixo comum?\",\"opcoes\":\"[\\\"Para facilitar o trabalho do caminhão de lixo.\\\",\\\"Para evitar multas.\\\",\\\"Para valorizar os materiais recicláveis e reduzir\\\\n o impacto ambiental.\\\",\\\"Para economizar espaço em casa.\\\"]\",\"correta_pergunta\":\"2\"}')),
    QuizQuestoesStruct.fromSerializableMap(jsonDecode(
        '{\"questao_texto\":\"Para economizar energia, devemos:\",\"opcoes\":\"[\\\"Ligar todos os aparelhos ao mesmo tempo.\\\",\\\"Deixar as luzes acesas durante o dia.\\\",\\\"Usar lâmpadas queimadas.\\\",\\\"Apagar as luzes ao sair de um cômodo.\\\"]\",\"correta_pergunta\":\"3\"}')),
    QuizQuestoesStruct.fromSerializableMap(jsonDecode(
        '{\"questao_texto\":\"O que é mais correto fazer com as pilhas usadas?\",\"opcoes\":\"[\\\"Jogar no vaso sanitário.\\\",\\\"Enterrar no quintal.\\\",\\\"Jogar no lixo comum.\\\",\\\"Levar para um local de coleta especial\\\"]\",\"correta_pergunta\":\"3\"}'))
  ];
  List<QuizQuestoesStruct> get quizQuestoes => _quizQuestoes;
  set quizQuestoes(List<QuizQuestoesStruct> value) {
    _quizQuestoes = value;
  }

  void addToQuizQuestoes(QuizQuestoesStruct value) {
    quizQuestoes.add(value);
  }

  void removeFromQuizQuestoes(QuizQuestoesStruct value) {
    quizQuestoes.remove(value);
  }

  void removeAtIndexFromQuizQuestoes(int index) {
    quizQuestoes.removeAt(index);
  }

  void updateQuizQuestoesAtIndex(
    int index,
    QuizQuestoesStruct Function(QuizQuestoesStruct) updateFn,
  ) {
    quizQuestoes[index] = updateFn(_quizQuestoes[index]);
  }

  void insertAtIndexInQuizQuestoes(int index, QuizQuestoesStruct value) {
    quizQuestoes.insert(index, value);
  }

  List<String> _login = [];
  List<String> get login => _login;
  set login(List<String> value) {
    _login = value;
    prefs.setStringList('ff_login', value);
  }

  void addToLogin(String value) {
    login.add(value);
    prefs.setStringList('ff_login', _login);
  }

  void removeFromLogin(String value) {
    login.remove(value);
    prefs.setStringList('ff_login', _login);
  }

  void removeAtIndexFromLogin(int index) {
    login.removeAt(index);
    prefs.setStringList('ff_login', _login);
  }

  void updateLoginAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    login[index] = updateFn(_login[index]);
    prefs.setStringList('ff_login', _login);
  }

  void insertAtIndexInLogin(int index, String value) {
    login.insert(index, value);
    prefs.setStringList('ff_login', _login);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
