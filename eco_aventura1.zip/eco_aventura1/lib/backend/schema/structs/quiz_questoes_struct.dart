// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class QuizQuestoesStruct extends FFFirebaseStruct {
  QuizQuestoesStruct({
    String? questaoTexto,
    List<String>? opcoes,
    int? corretaPergunta,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _questaoTexto = questaoTexto,
        _opcoes = opcoes,
        _corretaPergunta = corretaPergunta,
        super(firestoreUtilData);

  // "questao_texto" field.
  String? _questaoTexto;
  String get questaoTexto => _questaoTexto ?? '';
  set questaoTexto(String? val) => _questaoTexto = val;

  bool hasQuestaoTexto() => _questaoTexto != null;

  // "opcoes" field.
  List<String>? _opcoes;
  List<String> get opcoes => _opcoes ?? const [];
  set opcoes(List<String>? val) => _opcoes = val;

  void updateOpcoes(Function(List<String>) updateFn) {
    updateFn(_opcoes ??= []);
  }

  bool hasOpcoes() => _opcoes != null;

  // "correta_pergunta" field.
  int? _corretaPergunta;
  int get corretaPergunta => _corretaPergunta ?? 0;
  set corretaPergunta(int? val) => _corretaPergunta = val;

  void incrementCorretaPergunta(int amount) =>
      corretaPergunta = corretaPergunta + amount;

  bool hasCorretaPergunta() => _corretaPergunta != null;

  static QuizQuestoesStruct fromMap(Map<String, dynamic> data) =>
      QuizQuestoesStruct(
        questaoTexto: data['questao_texto'] as String?,
        opcoes: getDataList(data['opcoes']),
        corretaPergunta: castToType<int>(data['correta_pergunta']),
      );

  static QuizQuestoesStruct? maybeFromMap(dynamic data) => data is Map
      ? QuizQuestoesStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'questao_texto': _questaoTexto,
        'opcoes': _opcoes,
        'correta_pergunta': _corretaPergunta,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'questao_texto': serializeParam(
          _questaoTexto,
          ParamType.String,
        ),
        'opcoes': serializeParam(
          _opcoes,
          ParamType.String,
          isList: true,
        ),
        'correta_pergunta': serializeParam(
          _corretaPergunta,
          ParamType.int,
        ),
      }.withoutNulls;

  static QuizQuestoesStruct fromSerializableMap(Map<String, dynamic> data) =>
      QuizQuestoesStruct(
        questaoTexto: deserializeParam(
          data['questao_texto'],
          ParamType.String,
          false,
        ),
        opcoes: deserializeParam<String>(
          data['opcoes'],
          ParamType.String,
          true,
        ),
        corretaPergunta: deserializeParam(
          data['correta_pergunta'],
          ParamType.int,
          false,
        ),
      );

  @override
  String toString() => 'QuizQuestoesStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    const listEquality = ListEquality();
    return other is QuizQuestoesStruct &&
        questaoTexto == other.questaoTexto &&
        listEquality.equals(opcoes, other.opcoes) &&
        corretaPergunta == other.corretaPergunta;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([questaoTexto, opcoes, corretaPergunta]);
}

QuizQuestoesStruct createQuizQuestoesStruct({
  String? questaoTexto,
  int? corretaPergunta,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    QuizQuestoesStruct(
      questaoTexto: questaoTexto,
      corretaPergunta: corretaPergunta,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

QuizQuestoesStruct? updateQuizQuestoesStruct(
  QuizQuestoesStruct? quizQuestoes, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    quizQuestoes
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addQuizQuestoesStructData(
  Map<String, dynamic> firestoreData,
  QuizQuestoesStruct? quizQuestoes,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (quizQuestoes == null) {
    return;
  }
  if (quizQuestoes.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && quizQuestoes.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final quizQuestoesData =
      getQuizQuestoesFirestoreData(quizQuestoes, forFieldValue);
  final nestedData =
      quizQuestoesData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = quizQuestoes.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getQuizQuestoesFirestoreData(
  QuizQuestoesStruct? quizQuestoes, [
  bool forFieldValue = false,
]) {
  if (quizQuestoes == null) {
    return {};
  }
  final firestoreData = mapToFirestore(quizQuestoes.toMap());

  // Add any Firestore field values
  quizQuestoes.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getQuizQuestoesListFirestoreData(
  List<QuizQuestoesStruct>? quizQuestoess,
) =>
    quizQuestoess?.map((e) => getQuizQuestoesFirestoreData(e, true)).toList() ??
    [];
