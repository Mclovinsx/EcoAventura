import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CollectionUsersRecord extends FirestoreRecord {
  CollectionUsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "Zona" field.
  String? _zona;
  String get zona => _zona ?? '';
  bool hasZona() => _zona != null;

  // "nivel" field.
  String? _nivel;
  String get nivel => _nivel ?? '';
  bool hasNivel() => _nivel != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "photo_url1" field.
  String? _photoUrl1;
  String get photoUrl1 => _photoUrl1 ?? '';
  bool hasPhotoUrl1() => _photoUrl1 != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _zona = snapshotData['Zona'] as String?;
    _nivel = snapshotData['nivel'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _photoUrl1 = snapshotData['photo_url1'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('collection_users');

  static Stream<CollectionUsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CollectionUsersRecord.fromSnapshot(s));

  static Future<CollectionUsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CollectionUsersRecord.fromSnapshot(s));

  static CollectionUsersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CollectionUsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CollectionUsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CollectionUsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CollectionUsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CollectionUsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCollectionUsersRecordData({
  String? email,
  String? displayName,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? zona,
  String? nivel,
  String? photoUrl,
  String? photoUrl1,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'Zona': zona,
      'nivel': nivel,
      'photo_url': photoUrl,
      'photo_url1': photoUrl1,
    }.withoutNulls,
  );

  return firestoreData;
}

class CollectionUsersRecordDocumentEquality
    implements Equality<CollectionUsersRecord> {
  const CollectionUsersRecordDocumentEquality();

  @override
  bool equals(CollectionUsersRecord? e1, CollectionUsersRecord? e2) {
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.zona == e2?.zona &&
        e1?.nivel == e2?.nivel &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.photoUrl1 == e2?.photoUrl1;
  }

  @override
  int hash(CollectionUsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.zona,
        e?.nivel,
        e?.photoUrl,
        e?.photoUrl1
      ]);

  @override
  bool isValidKey(Object? o) => o is CollectionUsersRecord;
}
