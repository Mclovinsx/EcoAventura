import '../database.dart';

class QuizCategoriaTable extends SupabaseTable<QuizCategoriaRow> {
  @override
  String get tableName => 'quiz_categoria';

  @override
  QuizCategoriaRow createRow(Map<String, dynamic> data) =>
      QuizCategoriaRow(data);
}

class QuizCategoriaRow extends SupabaseDataRow {
  QuizCategoriaRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => QuizCategoriaTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  String? get nome => getField<String>('nome');
  set nome(String? value) => setField<String>('nome', value);
}
