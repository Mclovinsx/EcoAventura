import '../database.dart';

class QuizQuestoesTable extends SupabaseTable<QuizQuestoesRow> {
  @override
  String get tableName => 'quiz_questoes';

  @override
  QuizQuestoesRow createRow(Map<String, dynamic> data) => QuizQuestoesRow(data);
}

class QuizQuestoesRow extends SupabaseDataRow {
  QuizQuestoesRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => QuizQuestoesTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  int? get categoriaId => getField<int>('categoria_id');
  set categoriaId(int? value) => setField<int>('categoria_id', value);

  String? get questao => getField<String>('questao');
  set questao(String? value) => setField<String>('questao', value);

  String? get opcao1 => getField<String>('opcao_1');
  set opcao1(String? value) => setField<String>('opcao_1', value);

  String? get opcao2 => getField<String>('opcao_2');
  set opcao2(String? value) => setField<String>('opcao_2', value);

  String? get opcao3 => getField<String>('opcao_3');
  set opcao3(String? value) => setField<String>('opcao_3', value);

  String? get opcao4 => getField<String>('opcao_4');
  set opcao4(String? value) => setField<String>('opcao_4', value);

  int? get opcaoCorreta => getField<int>('opcao_correta');
  set opcaoCorreta(int? value) => setField<int>('opcao_correta', value);
}
