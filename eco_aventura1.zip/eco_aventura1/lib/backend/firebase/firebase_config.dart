import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyD16BNKVGIWcEyVf0Oaf9oVqOpx98pNjlo",
            authDomain: "eco-aventura1-sk7xce.firebaseapp.com",
            projectId: "eco-aventura1-sk7xce",
            storageBucket: "eco-aventura1-sk7xce.firebasestorage.app",
            messagingSenderId: "570914975086",
            appId: "1:570914975086:web:5e7493c72954f773c7e57f"));
  } else {
    await Firebase.initializeApp();
  }
}
